package com.luvo;

import java.time.LocalDate;

public class Booking {

    private String customerName;
    private LocalDate date;
    private String status;

    public Booking() {
    }

    public Booking(String customerName, LocalDate date, String status) {
        this.customerName = customerName;
        this.date = date;
        this.status = status;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
