package com.luvo.controller;

import com.luvo.Booking;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
public class GuideController {

    @GetMapping("/guide")
    public String showGuidePage(Model model) {

        model.addAttribute("pageTitle", "Tour Guide - Luvo");

        // Sample bookings – you can later replace this with DB data
        List<Booking> bookings = new ArrayList<>();
        bookings.add(new Booking("Alex R.", LocalDate.of(2025, 4, 11), "Pending"));
        bookings.add(new Booking("Julie S.", LocalDate.of(2025, 4, 13), "Confirmed"));

        model.addAttribute("bookings", bookings);

        return "guide";   // -> guide.html (Thymeleaf template)
    }
}
